# Charte éditoriale du Cnam Pays de la Loire

Version 2 du 13 octobre 2026, complétée le 23 octobre 2026 (sections 2, 4 bis, 9, 10 et 11). Elle s'applique à tout contenu du nouveau site : pages de formation, pages de listing, pages institutionnelles, pages entreprises, actualités.

**Une annexe la complète**, en fin de document : « Construire une page », qui explique comment assembler une page (un public, la réponse au titre d'abord, le gras, les listes, les liens, les images, la relecture).

**Comment elle a été établie.** Analyse de 166 pages du site actuel (cnam-paysdelaloire.fr, octobre 2026, 56 000 mots hors menus et pieds de page) : pages institutionnelles, pages entreprises, 15 pages domaine, échantillon de fiches formation et d'actualités. Quand le site emploie majoritairement une forme, la charte la retient. Quand il hésite entre plusieurs formes, la charte en choisit une, indiquée « règle fixée ».

## 1. Qui parle, à qui

- **Le Cnam parle en « nous »** et s'adresse au lecteur en **« vous »**. Le site emploie « vous / votre / vos » 100 fois pour 10 000 mots, « nous / notre / nos » 73 fois.
- **Vouvoiement partout.** Le tutoiement relevé sur deux pages d'alternance pour les moins de 30 ans n'est pas repris (règle fixée).
- **Le nom** : « le Cnam Pays de la Loire » à la première mention d'une page, puis « le Cnam » ou « nous ». Toujours **Cnam**, jamais CNAM, cnam ou Cnam PDL (346 « Cnam » contre 4 « CNAM » sur le site). Le nom développé, « Conservatoire national des arts et métiers », s'écrit une fois au plus par page, quand il apporte quelque chose.
- **La signature du site** : « La formation professionnelle pour tous » (titre de la page d'accueil).

## 2. Ton

- **Institutionnel et accessible** : un établissement public qui parle à des adultes qui travaillent. Concret, orienté projet professionnel : changer de métier, monter en compétences, obtenir un diplôme.
- **Factuel.** Une affirmation s'appuie sur un fait vérifiable : un diplôme, une durée, un lieu, un chiffre sourcé.
- **Interdits** :
  - les majuscules d'insistance (« C'est LA solution ») et les titres entièrement en capitales (« INFOS PRATIQUES ») ;
  - le point d'exclamation dans les pages de formation, de listing et institutionnelles. Il reste possible dans une citation ou une actualité événementielle ;
  - les points de suspension en fin d'énumération : écrire « etc. » ou fermer la liste ;
  - les superlatifs sans preuve (« la meilleure formation », « incontournable ») ;
  - les promesses d'emploi, de salaire ou de débouché garanti ;
  - les formules qui hiérarchisent les enseignants, « pour la plupart » ou « en grande partie » : elles sous-entendent qu'il y a de bons et de moins bons enseignants. Écrire « enseignants pédagogues et intervenants professionnels issus du terrain ».

## 2 bis. Voix : un texte vivant

Les interdits ci-dessus évitent les excès. Ils ne suffisent pas à rendre un texte vivant. Cinq règles pour y arriver (ajoutées le 13 octobre 2026) :

1. **Partir d'une scène ou d'une situation, pas d'une liste.** Montrer quelqu'un au travail : « En agence, vous accompagnez un client dans son projet de crédit. » Une énumération de métiers en ouverture se lit comme un catalogue.
2. **Des verbes d'action, avec le lecteur pour sujet** : « vous évaluez », « vous négociez », « vous gérez ». Éviter les tournures où personne n'agit : « plusieurs dispositifs existent », « une offre adaptée est proposée ».
3. **Varier la longueur des phrases.** Une phrase courte porte l'idée forte. Deux phrases longues de suite au plus.
4. **Le chiffre est l'argument de la phrase**, pas un ajout en fin de paragraphe : « L'alternance est une porte d'entrée du secteur : 18 100 alternants dans la banque en 2025. »
5. **Parler à chaque lecteur selon sa situation** : « Salarié, vous… En reconversion, vous… Demandeur d'emploi, vous… », plutôt qu'une liste de dispositifs. Réservé à ce que la formation apporte à chacun. Pour une consigne pratique, la tournure se lit comme une injonction : « Salarié, vous vous formez sur votre temps personnel » est ambigu. On écrira plutôt « Vous suivez la formation sur votre temps libre, ou sur votre temps de travail si… ».
6. **Commencer chaque bloc par la réponse à son titre**, les détails ensuite. Voir l'annexe « Construire une page », section 2.
7. **Un chiffre décourageant est suivi d'un conseil** : un taux de réussite de 67 % ne reste pas seul, la phrase suivante dit comment réussir.

| Plat | Vivant |
|---|---|
| Plusieurs dispositifs existent selon votre situation : le CPF, le plan de développement des compétences, Transitions Pro ou les aides de France Travail. | Salarié, vous mobilisez votre CPF ou vous demandez à votre employeur de vous inscrire au plan de développement des compétences. En reconversion, Transitions Pro peut financer votre projet. Demandeur d'emploi, vous vous adressez à France Travail. |

## 3. Nommer les publics

| Employer | Pour | Ne pas employer |
|---|---|---|
| **élève** | toute personne inscrite au Cnam (usage du site : 56 occurrences, et du Cnam national) | auditeur, étudiant |
| **alternant** | la personne en alternance, quel que soit le contrat | |
| **apprenti** | seulement pour le contrat d'apprentissage | apprenti au sens général |
| **stagiaire**, **participant** | formations intra et inter pour les entreprises | élève, dans ce contexte |
| **collaborateurs** | les salariés, quand on s'adresse à l'entreprise | personnel, ressources |
| **apprenant** | seulement dans les formations de formateurs, où c'est le vocabulaire du métier | ailleurs |

« Auditeur » ne survit que dans les textes réglementaires qui l'emploient (tarifs VES), sans le reformuler.

## 4. Nommer l'offre et les modalités

| Employer | Ne pas employer | Précision |
|---|---|---|
| **formation courte** | unité d'enseignement, UE, module, matière | À la première mention de la page : « formations courtes (aussi appelées unités d'enseignement) », puis « formation courte » seul. Jamais le sigle « UE ». Pour les entreprises, dire « formation intra-entreprise » |
| **crédits ECTS** | crédits seul | |
| **formation qualifiante** | bloc de compétences | À la première mention de la page : « formations qualifiantes (aussi appelées blocs de compétences) », puis « formation qualifiante » seul. Ensuite, jamais « bloc » seul comme sujet d'une phrase : c'est du jargon Cnam, le lecteur ne sait pas de quoi on parle. Le terme reste dans le title et la meta, où il a du volume de recherche. Ne s'applique pas aux fiches formation importées |
| **certificat de compétence**, **micro-certification**, **diplôme**, **titre RNCP** | certif, titre inscrit au RNCP | Nommer le type exact de certification. « titre RNCP », forme courte |
| **diplôme reconnu par l'État** | diplôme national, diplôme reconnu (seul) | Formule du site (« Diplômes reconnus par l'État ») ; « reconnu » s'emploie toujours avec « par l'État » |
| **RNCP** = Répertoire national des certifications professionnelles | « compétences professionnelles » | Erreur fréquente des sources grand public |
| **à distance** | e-learning, FOAD, distanciel | Usage du site : 77 « à distance » contre 24 « e-learning ». Exception : le sous-titre des fiches intra garde « présentiel, distanciel ou hybride » |
| **en présentiel**, **hybride** | mixte, blended | |
| **à distance**, **en ligne**, **en autonomie** | cours du soir, cours du samedi, HTT | **Il n'y a plus de cours du soir** : hors alternance, les cours se suivent en ligne, à distance. Les modalités à citer sont l'alternance et la formation à distance |
| **en alternance** | en apprentissage, au sens général | |
| **formation intra** (dans vos locaux, pour vos équipes), **formation inter** (avec d'autres entreprises) | | |
| **validation des acquis de l'expérience (VAE)**, **validation des études supérieures (VES)** | équivalence | Développer à la première mention |

Les codes de formation (LG03610A, MR132B40…) restent tels qu'ils apparaissent dans le catalogue.

## 4 bis. Des textes indépendants du catalogue

**Le catalogue bouge, les textes non** : si les formations changent, le texte ne doit pas être périmé. Dans tout texte rédigé hors fiche formation (pages de listing, pages institutionnelles, blocs éditoriaux), ne pas écrire :

- un intitulé, un sigle ou un code de formation précise (« DCG », « licence Commerce, vente, marketing ») ;
- une liste de métiers ou de débouchés tirée des fiches d'une formation ;
- une ville, un domaine ou une spécialité associés à l'offre (« à Angers et à Cholet », « de la gestion à la QSE ») ;
- un nombre de formations ou de villes (« dans 11 villes »).

Écrire ce qui dure : niveaux, voies d'entrée, modalités, financement, poursuite d'études, chiffres publics sourcés. La liste automatique de la page porte l'offre. Quand un fait ne vaut que pour une partie de l'offre : « certaines », « plusieurs », ou ne pas l'écrire. Les fiches formation, elles, décrivent leur formation.

## 5. Financement

Le financement se mentionne sans jamais affirmer l'éligibilité d'une formation : l'éligibilité se vérifie sur la fiche de la formation. Dispositifs à citer selon le public :

- **CPF** (compte personnel de formation) : salariés et demandeurs d'emploi.
- **OPCO** (opérateur de compétences) : alternance, plan de développement des compétences.
- **Plan de développement des compétences** : à l'initiative de l'employeur.
- **AIF** (aide individuelle à la formation) de France Travail : demandeurs d'emploi.
- **Transitions Pro** (projet de transition professionnelle) : salariés en reconversion.
- **FAF** (fonds d'assurance formation) : travailleurs indépendants.
- **Agefiph** : personnes en situation de handicap.

## 6. Ancrage régional

Citer les villes, c'est ce qui distingue le Cnam Pays de la Loire des organismes nationaux.

- **6 campus** : Nantes (siège, 25 boulevard Guy Mollet), Angers, La Roche-sur-Yon, Laval, Le Mans, Saint-Nazaire.
- **Autres lieux de formation** : Cholet, Clisson, Saint-Laurent-sur-Sèvre, Les Sables-d'Olonne, Saumur, Segré, et l'ICH Ouest pour l'immobilier.
- Une ville ne s'écrit sur une page que si la formation y est réellement proposée.

## 7. Chiffres

- Un chiffre s'écrit avec **sa source et son année**. Sans source, il ne s'écrit pas.
- **Format de citation** : la source et l'année entre parenthèses, après le chiffre ou la phrase qui le porte, introduites par « Source : » et **sans lien** : « 25 200 alternants en 2025 (Source : Fédération bancaire française et Observatoire de l'évolution des métiers de l'assurance, 2025) ». Nom de l'organisme en toutes lettres, avec sa casse (« Fédération bancaire française »). Quand un total additionne deux sources, citer les deux.
- **Chiffres du Cnam Pays de la Loire** (page « Chiffres clés et rapport d'activité », année 2025) : 14 590 élèves, 153 collaborateurs, 950 enseignants agréés dont 89 % de professionnels, 31 partenaires de formation.
- **Chiffres du Cnam national** (même page) : 55 000 élèves, plus d'un million d'anciens élèves, 230 implantations.
- **Chiffres d'un secteur** (emplois, recrutements) : seulement avec une source publique datée (Insee, France Travail, Dares, observatoire de branche). Les chiffres sectoriels des pages domaine actuelles, sans source ni date, ne sont pas repris tels quels.
- **Indicateurs de résultats** (réussite, satisfaction) : ceux de la fiche de la formation, sans arrondi ni extrapolation.

## 8. Typographie (règles fixées)

Le site actuel varie sur chacun de ces points. Les règles suivantes s'appliquent au nouveau site.

| Sujet | Règle | Exemple |
|---|---|---|
| Guillemets | Français, avec espace insécable | « Le Cnam, ça redonne confiance » |
| Tirets | Tiret simple, jamais de tiret long ni moyen | Nantes - Saint-Nazaire |
| Durée dans un texte | En toutes lettres pour l'unité | une formation de 35 heures |
| Durée dans un bloc d'infos | Abrégée | 21 h (3 jours) |
| Horaire | Espace avant et après « h » | de 18 h à 21 h 30 |
| Niveau | « bac +3 » dans une phrase, « Bac +3 (niveau 6) » en libellé | une licence de niveau bac +3 |
| Pourcentage, euro | Espace insécable avant le signe | 89 %, 1 300 € |
| Titres | Majuscule initiale seule, sans point final | Conditions d'accès |
| Énumération ouverte | « etc. », jamais « ... » | |
| Écriture inclusive | Ni point médian ni parenthèses. Doublet complet quand le genre compte (« les candidates et les candidats »), sinon masculin générique. Intitulés de métier : forme du référentiel RNCP | |
| Point final | Toute phrase qui contient une ponctuation (virgule, deux-points, point-virgule) se termine par un point, y compris dans une puce, une description ou une cellule de liste. Une puce de quelques mots sans ponctuation n'en prend pas | Rigueur : précision et sens du détail. |
| Gras | Un passage par paragraphe au plus, un à deux mots par puce. Jamais de phrase entière en gras. **Le gras porte la réponse au titre du bloc**, jamais un chiffre ou un détail | Titre « Ce que l'entretien change pour vous » : gras sur « bâtir votre plan de développement des compétences » |
| Noms de lieux composés | Ne se coupent pas en fin de ligne : dans les pages, entourés d'une balise qui interdit la coupure (`white-space:nowrap`), le trait d'union restant un trait d'union simple | La Roche-sur-Yon, Les Sables-d'Olonne |
| Listes | Étapes : liste numérotée, un libellé court en gras par étape. Options à comparer : liste à puces, l'option en gras en tête | 1. **Le cadrage** : … |

## 9. Liens et boutons

- **L'ancre dit où mène le lien** : « Voir les formations en alternance », « Consulter les tarifs ». Pas de « En savoir plus », « Découvrir » ou « Cliquez ici » seuls (plus de 50 sur l’échantillon du site actuel).
- Un bouton commence par un verbe à l'infinitif : « Télécharger la plaquette », « Nous contacter ».
- **Un paragraphe ne se termine jamais par un lien** : le lien devient un bouton en fin de bloc.
- **Pages sœurs** (même niveau : autres domaines, autres types de formation, autres villes) : liées seulement dans le bloc prévu pour elles, en bas de page. **Pages filles et autres pages** : dans les textes ou en bouton, là où le lecteur en a besoin.
- Un lien mène à l'étape suivante du lecteur : sur une page qui s'adresse aux employeurs, le contact mène au contact entreprise.
- **Un renvoi vers un contact donne le contact** : « contactez l'équipe » sans coordonnées ne sert à rien. Écrire l'adresse, en lien `mailto:`. Accessibilité et handicap : la référente handicap régionale, handi@cnam-paysdelaloire.fr.

## 10. Structure par type de page

- **Toute page** : l'annexe « Construire une page », en fin de document (un public par page, réponse au titre d'abord, liens, images, pas de recopie entre pages sœurs).
- Pour tout gabarit : le titre H1 est unique et décrit la page. Les sous-titres sont descriptifs, sans jeu de mots. Un terme technique (ECTS, RNCP, VAE) est expliqué en une phrase simple à sa première apparition.

## 11. Contrôle avant publication

- [ ] Vouvoiement, « nous » pour le Cnam, « Cnam » partout.
- [ ] « élève » pour les inscrits, « stagiaires » ou « participants » en intra.
- [ ] « à distance », pas « e-learning » ni « FOAD » ; ni « cours du soir » ni « HTT ».
- [ ] Aucun chiffre sans source ni année ; aucune éligibilité affirmée sans la fiche.
- [ ] Chaque source au format « (Source : organisme, année) », sans lien.
- [ ] Aucune ville citée où la formation n'est pas proposée.
- [ ] Hors fiche formation : aucun intitulé de formation, aucune liste de métiers, de villes ou de domaines tirée du catalogue (section 4 bis).
- [ ] Aucun « pour la plupart » ni « en grande partie » à propos des enseignants ; tout « contactez » suivi d'une coordonnée.
- [ ] Aucun point d'exclamation, aucune majuscule d'insistance, aucun titre en capitales.
- [ ] Guillemets français, tiret simple, espaces insécables avant %, €, :, ?, !.
- [ ] Point final à toute phrase qui contient une ponctuation, puces comprises.
- [ ] Aucune ancre « En savoir plus » seule.
- [ ] Chaque bloc commence par la réponse à son titre, et le gras porte cette réponse.
- [ ] Aucun paragraphe ne finit par un lien ; les pages sœurs ne sont liées que dans le bloc du bas.
- [ ] Aucune information donnée deux fois sur la page ; aucun angle recopié d'une page sœur.
- [ ] Aucun jargon non expliqué (« formation qualifiante (aussi appelée bloc de compétences) », jamais « bloc » seul).
- [ ] Images des blocs en paysage, jamais réemployées d'une autre page.

## Annexe. Construire une page du site Cnam : blocs, gras, liens, publics

Complément de la charte ci-dessus. La charte dit **quels mots** employer. Ce document dit **comment assembler une page**. Il est tiré des relectures, en octobre 2026, de les pages de listing (domaines, villes, niveaux, types de formation) du nouveau site. Chaque règle porte sa raison, pour qu'on sache l'appliquer à un cas nouveau.

### 1. Un public par page

Avant d'écrire, nommer **le lecteur principal** de la page, à partir des données des fiches (champ « public », prérequis, durée), pas d'une intuition. Puis écrire pour lui, et seulement en second pour les autres.

| Type d'offre | Lecteur principal | Ce qu'il cherche | Ce qui ne lui parle pas |
|---|---|---|---|
| Alternance | étudiants et jeunes demandeurs d'emploi | salaire, entreprise d'accueil, diplôme | reconversion, CPF |
| Diplômes et certifications (hors alternance) | actifs en poste, sur 2 ans en moyenne | tenir sur la durée, diplôme reconnu | aides à l'embauche |
| Formations courtes | salariés qui veulent une compétence | temps, financement, organisation au quotidien | cursus long |
| Formations qualifiantes | professionnels déjà diplômés (souvent bac +2 ou licence) | spécialisation reconnue, évolution de carrière | découverte d'un métier |
| Formations intra | employeurs **et** salariés concernés | déroulé, financement, obligations | parcours individuel |

**Quand une page sert deux publics**, le bloc qui ne parle qu'à l'un le dit dans son titre : « Entreprise : financer une formation intra avec votre OPCO ». Le lecteur voit tout de suite s'il est concerné.

**Le public secondaire ne passe jamais en premier.** Sur l'alternance, le bloc « après 26 ans » vient après le salaire et la recherche d'entreprise.

### 2. Un bloc = une question, et la réponse d'abord

- **Le titre pose une question ou une promesse précise**, de préférence une requête réelle : « Combien de temps dure une formation courte ? », « Formation intra ou inter-entreprise : laquelle choisir ? ».
- **La première phrase y répond.** Les dates, les chiffres et les conditions viennent après. On écrit en pyramide inversée : un lecteur qui s'arrête à la première phrase a sa réponse.
- **Le gras porte la réponse au titre**, et rien d'autre : ni un chiffre, ni un détail, ni un nom de dispositif.

| À éviter | À faire |
|---|---|
| Titre « Ce que l'entretien de parcours professionnel change pour vous ». Le bloc commence par « Depuis le 26 octobre 2025, l'entretien professionnel devient l'**entretien de parcours professionnel** » et la réponse arrive à la fin | « L'entretien de parcours professionnel fait apparaître les besoins de formation de vos collaborateurs : c'est le moment de **bâtir votre plan de développement des compétences**. » Puis la loi, puis les délais |
| Titre « Comment vous organiser ». Le bloc explique les crédits ECTS | Le quotidien réel : « Vous travaillez **quand vous le voulez** : le soir, le week-end ou à la pause… », puis comment joindre l'enseignant, puis le calendrier |

**L'introduction donne envie** (pages villes, 23/10/2026). Après le « où » ou le « quoi », une phrase sur le public formé, le type d'enseignement ou sa qualité, puis l'appel à découvrir. Une intro qui se contente de situer a été jugée « pas assez vendeuse ». Exemple : « Le Cnam d'Angers vous accueille rue de la Barre, dans une ville classée première ville verte de France. Salariés, alternants ou demandeurs d'emploi, vous y apprenez auprès d'enseignants pédagogues et d'intervenants professionnels issus du terrain. Découvrez nos formations pour progresser dans votre métier ou en changer. »

**Le titre décrit ce que contient le bloc.** Refusé : « Vos interlocuteurs pour Clisson » au-dessus de puces qui décrivaient les modalités (cours sur place, alternance). Devenu « Suivre votre formation à Clisson ».

**Vérifier que le texte répond vraiment au titre.** Un bloc « comment s'organiser » parle du quotidien d'un salarié qui se forme en plus de son travail : créneaux, outils, aide. Il ne parle pas de la façon dont on compte les crédits.

### 3. Des phrases qu'on ne peut pas mal lire

- **Une phrase est soit un constat, soit un conseil, soit une consigne.** Le lecteur doit savoir laquelle il lit. « Salarié, vous vous formez sur votre temps personnel, ou sur votre temps de travail si… » se lit à la fois comme une injonction et comme une description. Mieux : « Vous suivez la formation sur votre temps libre, de votre propre initiative, ou sur votre temps de travail si votre employeur l'inscrit au plan de développement des compétences. »
- **La règle 5 de la charte (« Salarié, vous… ») vaut pour décrire ce que la formation apporte à chacun**, pas pour une consigne pratique.
- **Un mot de jargon ne sert jamais de sujet à une phrase** tant qu'il n'est pas expliqué. « Une fois validé, chaque bloc vous donne… » : quel bloc ? Le lecteur ne sait pas de quoi on parle.
- **Un chiffre décourageant est suivi d'un conseil.** « 67 % de réussite entièrement à distance » ne reste pas seul : la phrase suivante dit comment faire partie des 67 %, puis propose une solution (l'hybride pour qui a besoin d'un cadre).

### 4. Le bon format pour l'information

| L'information est… | Format |
|---|---|
| Une suite d'étapes | **liste numérotée**, un libellé court en gras par étape (« **Le cadrage** : … ») |
| Deux ou trois options à comparer | **liste à puces**, l'option en gras en tête (« **En intra**, … » / « **En inter-entreprise**, … »), puis un paragraphe qui aide à choisir |
| Un parcours avec des pages à consulter | liste numérotée, un lien par étape |
| Un argument | paragraphe court |

### 5. Les liens

- **Un paragraphe ne se termine jamais par un lien.** Le lien devient un **bouton en fin de bloc**, avec un verbe à l'infinitif (« Trouver mon entreprise », « Consulter les plannings des cours »). Un lien au milieu d'une phrase reste possible.
- **Les pages sœurs** (même niveau : les autres types de formation, les autres domaines, les autres villes) **ne sont liées que dans le bloc prévu pour elles**, en bas de page, jamais dans les textes ni en bouton ailleurs.
- **Les pages filles et les autres pages du site** (guide de l'alternance, plannings, contact entreprise) se lient dans les textes ou en bouton, là où le lecteur en a besoin.
- **Un lien sert l'étape suivante du lecteur**, pas l'existence d'une page. Le contact d'une page pour les employeurs mène au contact entreprise, pas au contact général.

### 6. Une page sœur n'en recopie pas une autre

Deux pages du même niveau (deux types de formation, deux domaines, deux villes) n'ont **jamais le même angle ni le même conseil**, même reformulé. Avant d'écrire un bloc, relire les pages sœurs déjà en ligne.

Exemple corrigé le 23/10/2026 : les pages diplômantes et formations courtes portaient toutes deux le conseil de régularité et le bloc « additionner les formations jusqu'au diplôme ». La page diplômantes a pris un angle à elle :
- avancer un semestre à la fois, sur une durée de deux ans ;
- raccourcir son diplôme grâce à ses acquis (VES, VAE).

Un même fait peut figurer sur deux pages (le barème des crédits ECTS, par exemple). Un même bloc ne le peut pas.

**Pas de bloc commun à toute une famille de pages**. Refusés sur les pages villes : un bloc financement, les chiffres régionaux, la section HANDI'CNAM, la liste régionale de partenaires. Même adaptés au nom de la ville, ils restent du contenu dupliqué. Un bloc n'entre que s'il dit quelque chose de propre à la page, et **sans donnée propre, pas de bloc** : un bloc « à fournir » ne se publie pas.

**Une page voisine donne le fond, jamais la forme.** La page ville reprend des faits de la page campus (secteurs qui recrutent, temps de trajet, lieux de détente), réécrits. Les parties de gabarit commun aux pages campus (écosystème, publics accueillis) ne servent pas : elles ne disent rien de propre à la ville.

### 7. Les images des blocs média et texte

- **En paysage**, jamais en portrait : une image en hauteur allonge le bloc et crée un grand vide à côté du texte.
- **Des photos de personnes** de la médiathèque, en lien avec le sujet du bloc.
- **Jamais réemployée** d'une autre page de listing : vérifier aussi les recadrages existants (`600x400`, `956x717`). Une photo source déjà recadrée ailleurs compte comme réemployée.
- **Le bloc du bas** (pages sœurs) : texte à gauche, grande image à droite. Les blocs au-dessus alternent de façon à ne jamais avoir deux images du même côté d'affilée.

### 8. Sources

- **La source accompagne un chiffre ou une règle précise** (âge, montant, délai), au format de la charte. Une phrase générale sur un dispositif (« le Cnam est certifié Qualiopi, la condition pour que votre OPCO prenne en charge la formation ») n'en prend pas : les « (Source : code du travail, 2026) » en série alourdissent sans rien prouver au lecteur.
- **Pas de source dans l'introduction.** L'intro présente : elle porte la durée moyenne ou le public, sans parenthèse.
- **Un chiffre du Cnam sans année connue** (« plus de 1 700 entreprises partenaires ») s'écrit avec l'année de la page qui l'affiche, et se signale pour correction.

### 9. Relire avant d'enregistrer

1. Relire la page entière de haut en bas, comme un visiteur.
2. Pour chaque bloc : la première phrase répond-elle au titre ? Le gras est-il sur cette réponse ?
3. Chasser toute information donnée deux fois sur la page (« à distance » dans l'intro puis dans un bloc, « diplôme reconnu par l'État » deux fois…). Une carte de contact compte : l'adresse et l'accès qu'elle donne ne se répètent pas dans le texte voisin, et le nom d'un établissement ne se répète pas dans le bloc qui suit son titre.
4. Comparer aux pages sœurs : aucun angle recopié.
5. Fin de chaque paragraphe : pas de lien.
6. Chaque titre décrit son bloc ; chaque « contactez » donne une coordonnée.
7. Jargon : chaque sigle et chaque terme Cnam est expliqué à sa première apparition (« formation qualifiante (aussi appelée « bloc de compétences ») »).


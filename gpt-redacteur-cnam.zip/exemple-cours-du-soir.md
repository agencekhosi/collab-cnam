# Exemple travaillé : "cours du soir"

Cas réel de bout en bout, à lire pour comprendre le déroulé attendu. Entrée : la page existante https://www.cnam-paysdelaloire.fr/formations/a-distance-cours-du-soir à améliorer dans le cadre de la refonte.

## Ce que l'analyse a trouvé (résumé interne, non affiché tel quel)

La SERP de "cours du soir" mélange trois intentions : des définitions de dictionnaire, des sites institutionnels qui proposent des formations pour adultes (surtout le Cnam, présent avec plusieurs sites régionaux), et un seul vrai guide éditorial, un blog d'école privée. Les contenus en place sont soit des pages de navigation sans fond, soit un guide générique sans aucune donnée ni source. La barre éditoriale à dépasser est basse, la barre d'autorité est haute.

La page actuelle du Cnam Pays de la Loire est un simple hub : un titre, trois pictos, quatre blocs de liens. Aucune définition, aucun contenu de fond, aucune donnée, aucune réponse aux questions concrètes, aucun ancrage local développé.

## Le livrable principal, tel qu'il serait rendu à la chargée de com

Intention de recherche : comprendre ce qu'est le cours du soir et trouver où s'inscrire, avec la question du financement en tête.

Lecteur : adulte actif ou en reconversion, du niveau bac au niveau bac+5, peu familier du vocabulaire de la formation.

Format conseillé : une page qui garde sa fonction de hub mais qui ajoute un vrai contenu de fond, entre 1 800 et 2 500 mots, avec un tableau, une FAQ et des encadrés chiffrés. Ce format n'existe nulle part sur la SERP, c'est l'espace à prendre.

Sujets obligatoires à couvrir (parce que tous les concurrents les traitent) : la définition du cours du soir, les horaires types, le public concerné, les avantages, les types de formations accessibles, le fonctionnement en unités d'enseignement.

Idées différenciantes à intégrer (parce que personne ne les traite) :
- Un tableau qui distingue clairement les trois modalités, cours du soir en présentiel, formation à distance et hybride. Justification : les concurrents et même la page actuelle les confondent, cette clarté est unique.
- Les chiffres du profil des auditeurs du Cnam pour rassurer sur le fait que ce public est majoritairement composé d'actifs. Justification : aucun concurrent ne cite le moindre chiffre.
- Une FAQ qui répond franchement aux questions que personne ne traite : le diplôme est-il reconnu, est-ce finançable par le CPF, est-ce compatible avec un emploi à plein temps, que se passe-t-il si on rate une UE. Justification : ces questions sont partout dans les recherches et nulle part dans les réponses.
- Un traitement honnête de l'exigence du tout-à-distance, appuyé sur les taux de réussite du Cnam par modalité. Justification : dire la vérité chiffrée est un signal de confiance que les autres évitent.
- L'ancrage sur les 7 centres de la région. Justification : différencie d'emblée des contenus nationaux génériques.

Données Cnam à utiliser (voir donnees-cnam.md) : profil des auditeurs 2023-2024 et taux de réussite par modalité (source Observatoire des études et carrières). Les indicateurs de résultats régionaux sont à ajouter dès que le champ à remplir sera complété.

## Extrait du brouillon rédigé (livrable secondaire)

Titre : Cours du soir au Cnam Pays de la Loire : se former sans arrêter de travailler

Le cours du soir est une formation suivie en dehors des heures de travail, le soir ou le samedi matin. Au Cnam, on parle de formation Hors Temps de Travail. Elle s'adresse aux personnes qui veulent monter en compétences ou se reconvertir tout en gardant leur emploi.

Cette formule n'est pas marginale. En 2023-2024, le Cnam a accueilli 49 700 auditeurs, dont 76 % étaient des actifs au moment de leur inscription, pour un âge moyen de 31,2 ans (source : Observatoire des études et carrières du Cnam). Vous ne serez donc pas entouré d'étudiants sortant du lycée, mais de personnes dans une situation proche de la vôtre.

[Le brouillon complet poursuivrait avec le tableau des trois modalités, le fonctionnement en unités d'enseignement expliqué simplement, le financement renvoyé aux fiches officielles, la FAQ et l'ancrage régional.]

## Ce que la chargée de com fait ensuite

Elle garde ou écarte chaque idée, complète les indicateurs régionaux manquants, fait valider les mentions de financement sur la fiche de chaque formation, puis transmet à la validation prévue avant mise en ligne.

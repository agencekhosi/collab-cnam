# Exemple travaillé : la page « formation à distance »

Cas réel de bout en bout, à lire pour comprendre le déroulé attendu. Entrée : la page existante https://www.cnam-paysdelaloire.fr/formations/a-distance-cours-du-soir à améliorer dans le cadre de la refonte.

## Ce que l'analyse a trouvé (résumé interne, non affiché tel quel)

La page actuelle se positionne sur « cours du soir », une requête très recherchée. Or le Cnam Pays de la Loire ne propose plus de cours du soir : hors alternance, les cours se suivent en ligne, à distance (charte, section 4). La page vise donc la formation à distance, et répond à l'internaute qui cherche « cours du soir » sans lui promettre une modalité qui n'existe plus.

La SERP mélange trois intentions : des définitions de dictionnaire, des sites institutionnels qui proposent des formations pour adultes (surtout le Cnam, présent avec plusieurs sites régionaux), et un seul vrai guide éditorial, un blog d'école privée. Les contenus en place sont soit des pages de navigation sans fond, soit un guide générique sans aucune donnée ni source. La barre éditoriale à dépasser est basse, la barre d'autorité est haute.

La page actuelle du Cnam Pays de la Loire est un simple hub : un titre, trois pictos, quatre blocs de liens. Aucune définition, aucun contenu de fond, aucune donnée, aucune réponse aux questions concrètes.

## Le livrable principal, tel qu'il serait rendu à la chargée de com

Intention de recherche : trouver une formation compatible avec un emploi, comprendre comment elle se suit, et savoir comment la financer.

Lecteur : adulte actif ou en reconversion, du niveau bac au niveau bac +5, peu familier du vocabulaire de la formation.

Format conseillé : une page qui garde sa fonction de hub mais qui ajoute un vrai contenu de fond, avec des listes, une FAQ et des encadrés chiffrés. Ce format n'existe nulle part sur la SERP, c'est l'espace à prendre.

Sujets obligatoires à couvrir (parce que tous les concurrents les traitent) : ce qu'est une formation à distance, le public concerné, l'organisation dans la semaine, les types de formations accessibles, le fonctionnement en formations courtes (aussi appelées unités d'enseignement).

Idées différenciantes à intégrer (parce que personne ne les traite) :
- Une liste qui distingue clairement les modalités : en alternance, à distance, hybride. Justification : les concurrents et même la page actuelle les confondent, cette clarté est unique.
- Les chiffres du profil des élèves du Cnam, pour rassurer sur le fait que ce public est majoritairement composé d'actifs. Justification : aucun concurrent ne cite le moindre chiffre.
- Une FAQ qui répond franchement aux questions que personne ne traite : le diplôme est-il reconnu par l'État, est-ce finançable par le CPF, est-ce compatible avec un emploi à plein temps, que se passe-t-il si on échoue à une formation courte. Justification : ces questions sont partout dans les recherches et nulle part dans les réponses.
- Un traitement honnête de l'exigence du tout-à-distance, appuyé sur les taux de réussite du Cnam par modalité, et suivi d'un conseil pour réussir. Justification : dire la vérité chiffrée est un signal de confiance que les autres évitent.

Données Cnam à utiliser (voir donnees-cnam.md) : profil des élèves 2023-2024 et taux de réussite par modalité (Observatoire des études et carrières du Cnam), chiffres clés 2025 du Cnam Pays de la Loire.

## Extrait du brouillon rédigé (livrable secondaire)

Titre : Formation à distance au Cnam Pays de la Loire : se former sans arrêter de travailler

Vous cherchez des cours du soir pour vous former sans quitter votre poste ? Au Cnam Pays de la Loire, les cours se suivent désormais à distance, en ligne, à votre rythme, avec des classes virtuelles en direct ou en différé.

Cette formule n'est pas marginale. En 2023-2024, le Cnam a accueilli 49 700 élèves, dont 76 % étaient des actifs au moment de leur inscription, pour un âge moyen de 31,2 ans (Source : Observatoire des études et carrières du Cnam, 2024). Vous ne serez donc pas entouré d'étudiants sortant du lycée, mais de personnes dans une situation proche de la vôtre.

[Le brouillon complet poursuivrait avec la liste des modalités, le fonctionnement en formations courtes expliqué simplement, le financement renvoyé aux fiches officielles, puis la FAQ.]

## Ce que la chargée de com fait ensuite

Elle garde ou écarte chaque idée, complète les indicateurs régionaux manquants, fait valider les mentions de financement sur la fiche de chaque formation, puis transmet à la validation prévue avant mise en ligne.

# Configuration du GPT personnalisé Rédacteur Cnam

Guide pour recréer la skill sous forme de GPT personnalisé ChatGPT. À suivre une fois, par la personne qui construit le GPT.

## Prérequis de plan (à connaître avant de vendre l'outil au client)

- Construire un GPT personnalisé nécessite un compte ChatGPT payant, Plus au minimum, côté constructeur.
- Utiliser le GPT nécessite un compte ChatGPT. Un GPT partagé par lien est utilisable par les titulaires de compte.
- Un utilisateur en ChatGPT gratuit tourne sur un modèle plus faible, avec un contexte limité (environ 16K tokens) et une navigation web bridée. Le benchmark sera plus superficiel et les fichiers de connaissance moins bien exploités. Pour un rendu correct, le client devrait être au moins en Plus.
- Ces règles bougent souvent. Vérifier l'état exact dans le compte concerné avant de s'engager.

## Étapes dans le GPT Builder

1. Dans ChatGPT, ouvrir "Explore GPTs" puis "Create". Aller sur l'onglet "Configure" (ne pas rester sur le mode conversationnel).
2. Renseigner le nom et la description ci-dessous.
3. Coller le contenu de `instructions-gpt.md` dans le champ "Instructions".
4. Ajouter les conversation starters ci-dessous.
5. Uploader les quatre fichiers de connaissance (section plus bas).
6. Cocher les capacités indiquées.
7. Choisir la visibilité : "Seulement moi" pour tester, puis "Tous ceux qui ont le lien" pour diffuser au client.

## Champs à renseigner

**Nom**
Rédacteur Cnam Pays de la Loire

**Description**
Analyse la concurrence sur un sujet et te rend des idées de contenu prêtes à utiliser pour le Cnam Pays de la Loire, puis un brouillon si tu le veux. Relit aussi un contenu déjà écrit et rend un verdict avec des corrections prioritaires. Pensé pour les chargés de communication débutants en référencement.

**Conversation starters**
- Que faut-il écrire pour se démarquer sur [sujet] ?
- Rédige un brouillon au ton du Cnam sur [sujet]
- Relis ce texte et dis-moi ce qui bloque : [colle le texte]
- Audite cette page : [colle l'URL]

## Capacités à activer

- Web Search (Recherche web) : OBLIGATOIRE. C'est ce qui fait tourner le benchmark. Sans elle, l'outil perd sa fonction principale.
- Code Interpreter et analyse de données : optionnel, sans intérêt ici, laisser décoché.
- Génération d'images : décoché.
- Canvas : optionnel, peut servir au confort de rédaction du brouillon.

## Fichiers de connaissance à uploader

Uploader ces quatre fichiers dans la section "Knowledge" :
- `charte-cnam.md`
- `donnees-cnam.md`
- `exemple-cours-du-soir.md`
- `grille-audit.md` (les six axes de relecture, utilisés en mode relecture)

Ces fichiers sont identiques à ceux de la skill Claude. Quand tu mets à jour la charte, les données ou la grille côté Claude, remplace aussi les fichiers ici, les deux outils doivent rester alignés.

## Différence importante avec la skill Claude

Dans la skill Claude, les fichiers de référence sont chargés de façon garantie. Dans un GPT, ils sont récupérés par recherche sémantique, sans garantie qu'ils soient consultés à chaque requête. Les instructions forcent leur lecture au démarrage, mais c'est moins fiable. Vérifier régulièrement, sur des cas tests, que le vocabulaire du Cnam et la règle de sourcing sont bien respectés.

## Test avant diffusion

Avant de donner le lien au client, lancer le GPT sur un ou deux sujets connus et vérifier trois choses :
1. Il consulte bien la charte (vocabulaire auditeur, UE, RNCP correct).
2. Il ne cite aucun chiffre absent de `donnees-cnam.md` et n'en invente pas.
3. Il signale quand la navigation n'a pu analyser que peu de pages, au lieu de faire semblant.

## Champ à compléter côté données

Le fichier `donnees-cnam.md` contient un champ "à remplir par le client" pour les indicateurs de résultats du Cnam Pays de la Loire. Tant qu'il est vide, l'outil ne citera aucun taux de réussite régional. Le compléter dès que le rapport d'activité fournit les chiffres, puis ré-uploader le fichier dans le GPT.

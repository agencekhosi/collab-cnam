# Configuration du GPT personnalisé Auditeur Cnam

Guide pour créer l'auditeur sous forme de GPT personnalisé ChatGPT. À suivre une fois, par la personne qui construit le GPT. C'est le pendant du GPT Rédacteur Cnam : le Rédacteur produit, l'Auditeur relit.

## Prérequis de plan (à connaître avant de vendre l'outil au client)

- Construire un GPT personnalisé nécessite un compte ChatGPT payant, Plus au minimum, côté constructeur.
- Utiliser le GPT nécessite un compte ChatGPT. Un GPT partagé par lien est utilisable par les titulaires de compte.
- Un utilisateur en ChatGPT gratuit tourne sur un modèle plus faible et exploite moins bien les fichiers de connaissance. Pour un audit fiable, le client devrait être au moins en Plus.
- Ces règles bougent souvent. Vérifier l'état exact dans le compte concerné avant de s'engager.

## Étapes dans le GPT Builder

1. Dans ChatGPT, ouvrir "Explore GPTs" puis "Create". Aller sur l'onglet "Configure".
2. Renseigner le nom et la description ci-dessous.
3. Coller le contenu de `instructions-gpt.md` dans le champ "Instructions".
4. Ajouter les conversation starters ci-dessous.
5. Uploader les trois fichiers de connaissance (section plus bas).
6. Cocher les capacités indiquées.
7. Choisir la visibilité : "Seulement moi" pour tester, puis "Tous ceux qui ont le lien" pour diffuser au client.

## Champs à renseigner

**Nom**
Auditeur Cnam Pays de la Loire

**Description**
Relit une page ou un brouillon du Cnam Pays de la Loire, rend un verdict (vert, orange, rouge) et des corrections concrètes, à partir de la checklist de rédaction web et de la charte du Cnam. Pensé pour les chargés de communication débutants en référencement.

**Conversation starters**
- Relis cette page : [colle le texte ou l'URL]
- Qu'est-ce qui ne va pas sur cette page ? [colle le contenu]
- Cette page est-elle prête à publier ? [colle le contenu]
- Fais-moi l'audit détaillé de ce contenu : [colle le texte]

## Capacités à activer

- Web Search (Recherche web) : OPTIONNELLE. Utile seulement si l'utilisateur donne une URL à faire lire. Pour un audit sur texte collé, elle n'est pas nécessaire. L'activer permet de gérer les deux cas ; sinon, demander à coller le texte.
- Code Interpreter et analyse de données : décoché.
- Génération d'images : décoché.
- Canvas : optionnel, peut servir au confort d'affichage des corrections.

## Fichiers de connaissance à uploader

Uploader ces trois fichiers dans la section "Knowledge" :
- `charte-cnam.md`
- `donnees-cnam.md`
- `grille-audit.md`

Ces fichiers sont identiques à ceux de la skill Claude audit-cnam (la charte et les données sont aussi partagées avec le Rédacteur). Quand tu mets à jour la charte ou les données côté Claude, remplace aussi les fichiers ici : tous les outils doivent rester alignés.

## Différence importante avec la skill Claude

Dans la skill Claude, les fichiers de référence sont chargés de façon garantie. Dans un GPT, ils sont récupérés par recherche sémantique, sans garantie qu'ils soient consultés à chaque requête. Les instructions forcent leur lecture au démarrage, mais c'est moins fiable. Vérifier régulièrement, sur des cas tests, que le vocabulaire du Cnam et la règle de sourcing sont bien respectés.

## Test avant diffusion

Avant de donner le lien au client, coller une page contenant volontairement quelques fautes et vérifier trois choses :
1. Il repère les entorses à la charte (par exemple "étudiant" au lieu d'"auditeur", un tiret cadratin, une promesse d'emploi) et les signale comme bloquantes.
2. Il n'invente aucun chiffre et n'en cite aucun qui soit absent de `donnees-cnam.md`.
3. Il rend bien un verdict clair (vert, orange, rouge) suivi de corrections concrètes, avant tout détail.

## Champ à compléter côté données

Le fichier `donnees-cnam.md` contient un champ "à remplir par le client" pour les indicateurs de résultats du Cnam Pays de la Loire. Tant qu'il est vide, l'outil ne s'appuiera sur aucun taux régional. Le compléter dès que le rapport d'activité fournit les chiffres, puis ré-uploader le fichier dans le GPT.

# Charte éditoriale Cnam Pays de la Loire

Ce fichier a été reconstruit par analyse du site cnam-paysdelaloire.fr et des sources institutionnelles du Cnam, faute de charte formelle existante. Il s'applique à tout contenu produit par la skill.

## Positionnement et ton

Le Cnam est un établissement public sous tutelle du ministère de l'Enseignement supérieur, fondé en 1794, dont la mission historique est la promotion sociale et la formation tout au long de la vie. Le Cnam Pays de la Loire décline cette mission sur son territoire, avec un siège à Nantes et des centres répartis dans la région.

Ton institutionnel mais accessible. Vouvoiement. Orienté projet professionnel et montée en compétences. Jamais scolaire, jamais marketing agressif, jamais de survente. Les publics visés sont les actifs qui veulent se perfectionner ou se reconvertir, les jeunes en alternance, les entreprises et collectivités, et les personnes éloignées de l'emploi qui veulent se former.

## Vocabulaire imposé

| À utiliser | À éviter | Pourquoi |
|---|---|---|
| auditeur, auditrice | étudiant, élève (sauf la formule "élèves (auditeurs)") | Terme identitaire du Cnam |
| unité d'enseignement (UE) | module, matière | Vocabulaire officiel du parcours |
| capitalisation, ECTS | crédits (employé vaguement) | Mécanisme réel de progression |
| Hors Temps de Travail (HTT) | cours du soir employé seul | Le cours du soir est une modalité du HTT, avec le cours du samedi |
| FOAD, à distance, hybride | e-learning, distanciel (flou) | Modalités officielles distinctes |
| titre inscrit au RNCP, diplôme national | diplôme reconnu (flou) | Précision réglementaire attendue |
| bloc de compétences, micro-certification | certif, petit module | Offre nommée du Cnam |
| formation tout au long de la vie | formation pour adultes | Formulation de la mission |
| validation des acquis (VAE, VES) | équivalence | Dispositifs officiels |

Attention à un piège fréquent : le sigle RNCP se développe en Répertoire national des certifications professionnelles. Des sources grand public écrivent à tort "compétences professionnelles". Toujours utiliser la forme exacte.

Les codes des formations en Pays de la Loire portent le suffixe PDL.

## Mentions obligatoires sur une page de formation ou une page commerciale

- La certification Qualiopi. Le Cnam Pays de la Loire l'a obtenue en 2021. Elle est obligatoire depuis le 1er janvier 2022 pour tout organisme voulant faire bénéficier ses formations de fonds publics ou mutualisés, dont le CPF.
- L'enregistrement au RNCP avec le code exact, lorsque la formation y est inscrite. Le Cnam délivre des diplômes nationaux (licence, master, diplôme d'ingénieur) et des titres inscrits au RNCP qu'il est habilité à délivrer.
- Le financement mentionné de façon prudente, sans affirmer une éligibilité qui n'a pas été vérifiée sur la fiche officielle.

## Panorama des financements (à piocher selon le public visé)

Ne jamais affirmer une éligibilité, toujours renvoyer à la fiche de la formation. Dispositifs existants :
- CPF (compte personnel de formation) : salariés et demandeurs d'emploi.
- OPCO (opérateurs de compétences) : alternants et professionnels.
- Plan de développement des compétences : à l'initiative de l'employeur.
- AIF (aide individuelle à la formation) via France Travail : demandeurs d'emploi.
- Transitions Pro (projet de transition professionnelle) : salariés en reconversion.
- FAF (fonds d'assurance formation) : travailleurs indépendants.
- AGEFIPH : personnes en situation de handicap.

## Ancrage territorial

- Siège : Nantes.
- Centres : Angers, La Roche-sur-Yon, Laval, Le Mans (chefs-lieux de département), Cholet, Saint-Nazaire.
- Sites complémentaires selon les formations : Châteaubriant, Saint-Laurent-sur-Sèvre, Clisson.

Mobiliser l'ancrage local est un différenciant fort face aux contenus nationaux ou génériques des concurrents.

## Style d'écriture

- Phrases courtes, structure aérée.
- Chaque terme technique expliqué en une phrase simple juste après sa première apparition (UE, ECTS, capitalisation, FOAD, RNCP ne sont pas connus du grand public).
- Chaque argument important appuyé par un exemple concret ou un chiffre sourcé.
- Titres descriptifs et fidèles au contenu.
- Aucun tiret cadratin.

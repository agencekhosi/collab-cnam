# Données Cnam autorisées

Ce fichier liste les seules sources de chiffres utilisables par la skill. Un chiffre absent de ces sources ne doit pas être écrit. Il est soit abandonné, soit signalé "à compléter par le Cnam".

## Règle

Toute statistique vient d'ici. Les faits réglementaires (éligibilité CPF, code RNCP, financement d'une formation précise) ne sont pas des statistiques : ils se vérifient sur la fiche officielle de la formation, jamais de mémoire.

## Source 1 : Observatoire des études et carrières du Cnam (national)

Données de cadrage sur le profil des auditeurs et la réussite. Utiles pour rassurer et pour l'information gain, car les concurrents ne citent aucun de ces chiffres.

Page de référence : https://eleves.cnam.fr/l-observatoire-des-etudes-et-carrieres/profil-des-auditeurs-du-cnam-1327703.kjsp
Chiffres clés téléchargeables : https://eleves.cnam.fr/medias/fichier/cc2024-synthese_1751989588439-pdf?ID_FICHE=1358253&INLINE=FALSE

Chiffres vérifiés (année universitaire 2023-2024, à re-vérifier à chaque nouvelle édition annuelle) :
- 49 700 auditeurs accueillis, pour près de 300 000 inscriptions.
- 76 % des auditeurs sont des actifs au moment de leur inscription.
- Âge moyen des auditeurs : 31,2 ans.
- La formation continue représente 71 % des inscrits, l'alternance le reste.
- La formation à distance ou hybride représente 54 % des inscriptions de l'offre nationale.
- 17 600 diplômes délivrés sur l'année.
- Réussite aux examens selon la modalité : la présence et la réussite sont plus faibles en formation 100 % à distance (présence 69 %, réussite 67 %) qu'en présentiel (présence 87 %, réussite 86 %) ou en hybride (présence 85 %, réussite 90 %). Donnée honnête utile pour parler franchement des exigences du tout-à-distance.

## Source 2 : chiffres régionaux Cnam Pays de la Loire

Page de référence : https://www.cnam-paysdelaloire.fr/le-cnam/chiffres-cles-rapport-dactivite

Chiffres repérés (à confirmer et actualiser sur le rapport d'activité le plus récent) :
- Environ 13 100 élèves inscrits (donnée 2021, à actualiser).
- Plus de 80 certifications professionnelles proposées.
- Réseau de 7 centres dans la région.
- Certification Qualiopi obtenue en 2021 pour l'ensemble des activités de formation et de service.

## Source 3 : indicateurs de résultats Cnam Pays de la Loire

Le site dispose d'une page d'indicateurs de résultats et d'un rapport d'activité annuel. Ces indicateurs locaux (taux de réussite, satisfaction, insertion) sont la preuve la plus forte pour l'information gain, car aucun concurrent générique n'en dispose. À citer formation par formation quand c'est pertinent.

CHAMP À REMPLIR PAR LE CLIENT. Les chiffres exacts et à jour de la page indicateurs de résultats n'ont pas pu être extraits automatiquement. Déposer ici, dès qu'ils sont disponibles :
- Taux de réussite par formation ou global :
- Taux de satisfaction des auditeurs :
- Taux d'insertion ou de retour à l'emploi :
- Note de satisfaction CPF (application Mon Compte Formation) :
- Année de référence des chiffres ci-dessus :

Tant que ce champ est vide, ne pas citer de chiffre régional de résultats. Renvoyer à la page indicateurs de résultats du site sans avancer de valeur précise.

# Données Cnam autorisées

Ce fichier liste les seules sources de chiffres utilisables par la skill. Un chiffre absent de ces sources ne doit pas être écrit. Il est soit abandonné, soit signalé « à compléter par le Cnam ».

## Règle

Toute statistique vient d'ici. Les faits réglementaires (éligibilité CPF, code RNCP, financement d'une formation précise) ne sont pas des statistiques : ils se vérifient sur la fiche officielle de la formation, jamais de mémoire.

Chaque chiffre s'écrit avec sa source et son année, au format de la charte : « (Source : organisme, année) », sans lien. Les personnes inscrites au Cnam sont des **élèves** (charte, section 3), même quand la source dit « auditeurs ».

## Source 1 : chiffres clés du Cnam Pays de la Loire et du Cnam national

Page de référence : https://www.cnam-paysdelaloire.fr/le-cnam/chiffres-cles-rapport-dactivite

Chiffres de l'année 2025 (à actualiser à chaque nouveau rapport d'activité) :
- Cnam Pays de la Loire : 14 590 élèves, 153 collaborateurs, 950 enseignants agréés dont 89 % de professionnels, 31 partenaires de formation.
- Cnam national : 55 000 élèves, plus d'un million d'anciens élèves, 230 implantations.

Le Cnam Pays de la Loire est certifié Qualiopi.

## Source 2 : Observatoire des études et carrières du Cnam (national)

Données de cadrage sur le profil des élèves et la réussite. Utiles pour rassurer et pour l'information gain, car les concurrents ne citent aucun de ces chiffres. Elles portent sur l'ensemble du Cnam, pas sur la région : ne pas les présenter comme des chiffres du Cnam Pays de la Loire.

Page de référence : https://eleves.cnam.fr/l-observatoire-des-etudes-et-carrieres/profil-des-auditeurs-du-cnam-1327703.kjsp
Chiffres clés téléchargeables : https://eleves.cnam.fr/medias/fichier/cc2024-synthese_1751989588439-pdf?ID_FICHE=1358253&INLINE=FALSE

Chiffres de l'année universitaire 2023-2024 (à vérifier à chaque nouvelle édition annuelle) :
- 49 700 élèves accueillis, pour près de 300 000 inscriptions.
- 76 % des élèves sont des actifs au moment de leur inscription.
- Âge moyen des élèves : 31,2 ans.
- La formation continue représente 71 % des inscrits, l'alternance le reste.
- La formation à distance ou hybride représente 54 % des inscriptions de l'offre nationale.
- 17 600 diplômes délivrés sur l'année.
- Réussite aux examens selon la modalité : la présence et la réussite sont plus faibles en formation entièrement à distance (présence 69 %, réussite 67 %) qu'en présentiel (présence 87 %, réussite 86 %) ou en hybride (présence 85 %, réussite 90 %). Donnée honnête, utile pour parler franchement des exigences du tout-à-distance : un chiffre décourageant est toujours suivi d'un conseil pour réussir (charte, section 2 bis).

Ne pas additionner ni comparer ces chiffres avec ceux de la source 1 : années et périmètres diffèrent (49 700 élèves accueillis en 2023-2024 selon l'Observatoire, 55 000 élèves en 2025 selon les chiffres clés).

## Source 3 : indicateurs de résultats du Cnam Pays de la Loire

Le site publie une page d'indicateurs de résultats et un rapport d'activité annuel. Ces indicateurs locaux (taux de réussite, satisfaction, insertion) sont la preuve la plus forte pour l'information gain, car aucun concurrent générique n'en dispose.

Chiffres publiés sur la page « Indicateurs de résultats » du nouveau site :
- Taux moyen de réussite aux examens des formations courtes : 86 % (2024-2025).
- Note moyenne des personnes financées par France Travail : 4,7/5 (2024).

Indicateurs d'une formation précise (réussite, satisfaction, insertion) : ceux de sa fiche, sans arrondi ni extrapolation, et jamais étendus à d'autres formations.

À COMPLÉTER PAR LE CNAM dès que disponibles :
- Taux d'insertion ou de retour à l'emploi global, avec son année :
- Note de satisfaction de l'application Mon Compte Formation, avec son année :

Tant qu'une ligne est vide, ne pas citer de chiffre sur ce point. Renvoyer à la page indicateurs de résultats du site sans avancer de valeur précise.

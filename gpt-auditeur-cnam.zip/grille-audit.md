# Grille d'audit de contenu Cnam Pays de la Loire

Grille de relecture appliquée à un contenu : une page en ligne, un brouillon, ou une page existante à améliorer. Pour chaque axe : ce qu'on vérifie, ce qui constitue un manquement, la direction de correction.

La charte (`charte-cnam.md`) prime sur tout le reste : une entorse à la charte est un manquement **bloquant**, quel que soit le niveau du contenu par ailleurs.

## Axe 1 — Intention et cible

- La page répond-elle à une intention de recherche claire (ce que cherche vraiment la personne) ?
- La cible est-elle identifiable (auditeur en reconversion, salarié, entreprise, demandeur d'emploi, alternant) ?
- Manquement : la page parle du Cnam avant de répondre au besoin ; cible floue ; sujet mal cerné.
- Correction : recentrer l'entrée de page sur le besoin de la personne, préciser à qui on s'adresse.

## Axe 2 — Structure et lisibilité

- Les titres et intertitres sont-ils la synthèse de leur paragraphe (jamais vagues) ? En lisant uniquement les titres et les mots en gras, comprend-on l'essentiel ?
- Paragraphes courts (3-4 lignes), listes à puces, gras sur ce qui fait sens ?
- Un seul H1, hiérarchie H2/H3 logique (pas de H3 avant un H2), un titre = une idée ?
- Manquement : titres passe-partout (« Présentation », « Informations »), pavés, gras posé sur les mots-clés, listes écrites en paragraphe.
- Correction : réécrire les titres en synthèses, découper les pavés, baliser proprement.

## Axe 3 — Réponse et haut de page (dont GEO)

- La réponse à l'intention est-elle donnée dès le haut de page (300 premiers mots) ?
- L'introduction synthétise-t-elle (on a l'essentiel en deux phrases) au lieu d'« introduire » ? Un TL;DR ou un bloc « à retenir » est un plus : il sert la position 0 et les moteurs IA (GEO).
- Manquement : introduction creuse, réponse enterrée en bas de page.
- Correction : remonter la réponse, ajouter un chapô synthétique ou un bloc « à retenir ».

## Axe 4 — Crédibilité (E-E-A-T)

- Le contenu prouve-t-il son sérieux : chiffres sourcés, preuves concrètes (témoignages d'auditeurs, exemples réels, mentions précises) ?
- Les chiffres viennent-ils exclusivement de `donnees-cnam.md` ?
- Manquement : affirmations non étayées, chiffres sans source ou inventés, superlatifs gratuits, visuels génériques de banque d'images.
- Correction : appuyer par une donnée Cnam sourcée, ou signaler « à compléter par le Cnam » ; remplacer le superlatif par un fait.

## Axe 5 — Charte Cnam (bloquant)

- Vocabulaire imposé respecté (auditeur, unité d'enseignement, Hors Temps de Travail, FOAD, titre inscrit au RNCP, bloc de compétences, validation des acquis) ? Termes à éviter absents (étudiant, module, cours du soir employé seul, e-learning, diplôme reconnu) ?
- Sigle RNCP développé correctement : Répertoire national des certifications professionnelles (jamais « compétences professionnelles ») ?
- Sur une page de formation : mentions Qualiopi, code RNCP quand la formation y est inscrite, financement formulé de façon prudente ?
- Aucune promesse d'emploi, de salaire ou d'éligibilité à un financement sans renvoi à la fiche officielle ?
- Aucun tiret cadratin ? Ton institutionnel accessible, vouvoiement, termes techniques expliqués à leur première apparition ?
- Manquement (bloquant) : toute entorse ci-dessus.
- Correction : remplacer par le terme imposé, ajouter la mention manquante, formuler le financement prudemment, retirer le cadratin.

## Axe 6 — SEO de base (si la page a une dimension de recherche)

- Balise Title : unique, 30 à 65 caractères, mot-clé de préférence au début, accroche qui donne envie de cliquer ?
- Méta description : 100 à 165 caractères, reprend le mot-clé, donne envie de cliquer ?
- URL courte et lisible : sans accents ni petits mots, avec des tirets ?
- Images : renommées avec un mot-clé, texte alternatif descriptif ?
- Mot-clé et variantes présents naturellement, vocabulaire du sujet riche ?
- Manquement : Title générique ou trop long, méta absente, URL à rallonge, images sans alt.
- Correction : proposer un Title, une méta et une URL conformes.

## Portée

- L'axe 6 ne s'applique pas à un contenu sans dimension de recherche (actualité institutionnelle pure, communiqué). Dans ce cas, auditer surtout les axes 2, 4 et 5.
- L'audit signale et corrige de façon ciblée. Il ne réécrit pas toute la page : la production complète relève de la skill Rédacteur Cnam.
